package fr.project.TaskManager.Projects;

import fr.project.TaskManager.Task.Task;
import fr.project.TaskManager.Task.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;


@Service

public class ProjectService {

    public final ProjectRepository projectRepository;
    public final TaskRepository taskRepository;

    @Autowired
    public ProjectService(ProjectRepository projectRepository, TaskRepository taskRepository) {
        this.projectRepository = projectRepository;
        this.taskRepository = taskRepository;
    }

    public List<Project> getProjects() {
       return projectRepository.findAll();

    }

    public void addNewProject(Project project) {

        List<Project> projects = projectRepository.findAll();

        for(Project projet : projects){
            if(projet.getName().equals(project.getName())){
                throw new IllegalStateException("Project name already exsit !");
                
            }
        }


        projectRepository.save(project);

    }
    /*@Transactional
    public void addNewTask(Long projectId, String projectName) {

        List<Task> tasks = taskRepository.findAll();
        Project project = projectRepository.findById(projectId).orElseThrow(
                ()->  new IllegalStateException("Project with Id " + projectId + " does not exist")

        );
        if(projectName != null ){
            project.setName(tasks.get(1).getName());
            //project.addTask(tasks.get(1));
        }







    }*/
}
