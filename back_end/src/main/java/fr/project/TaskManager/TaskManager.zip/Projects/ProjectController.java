package fr.project.TaskManager.Projects;

import fr.project.TaskManager.Task.Task;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path= "api/projects")
@CrossOrigin(origins = "*")
public class ProjectController {

    private final ProjectService projectService;


    @Autowired
    public ProjectController(ProjectService projectService) {
        this.projectService = projectService;
    }

    @GetMapping
    public List<Project> getProjects(){

        return projectService.getProjects();

    }

    @PostMapping
    public void registerNewProject(@RequestBody Project project){
        projectService.addNewProject(project);

    }



/*
    @PutMapping(path = "{projectId}")
    public void addTask(
            @PathVariable("projectId") Long projectId,
            @RequestParam( required = false) String projectName){
        projectService.addNewTask(projectId,projectName);
    }*/
}
